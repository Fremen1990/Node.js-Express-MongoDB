module.exports = {
  db: 'mongodb+srv://admin:p6tdGLXJBWOOOYSy@cluster0-0dwhe.mongodb.net/test?retryWrites=true',
  keySession: ['TWOJKLUCZ'],
  maxAgeSession: 24 * 60 * 60 * 1000
}